

class User {
    constructor(name, age,email) {
      this.name = name;
      this.age = age;
      this.email = email;
      this.letucoins = 0;
      this.courses = [];
    }

    static greet(){
        console.log("Hello There");
    }

    login(){
        console.log(`${this.name} has logged in`);
        return this;
    }
    logout(){
        console.log(`${this.name} has logged out`);
        return this;
    }
    
    getDetails(){
        console.log(`Name is ${this.name}, Email is ${this.email}`);
        return this;
    }

}

class Moderator extends User{
    
  addCoins(){
        this.letucoins++;
        console.log(`${this.name} has ${this.letucoins} coins`);
        return this;
    }
     delCoins(){
        this.letucoins--;
        console.log(`${this.name} has ${this.letucoins} coins`);
        return this;
    }
}

class Admin extends Moderator{
   addCourse(user,course){
       user.courses.push(course);
       console.log(user);
       return this;
   }
    delCourse(user,course){
       user.courses.pop(course);
       console.log(user);
       return this;
   }
}


let user1 = new User('viki',21,'viki@gmail.com')
let user2 = new User('anjali',18,'anjali@gmai.com')
let mod = new Moderator('meet',24,'meet@gmail.com','Moderator');
let admin = new Admin('ram',35,'ram@gmail.com');
let users = [user1,user2,mod,admin];

users.forEach(element => {
    console.log(element);
});

