var input = prompt('Enter array size');

var inputArray = [];
 
restartloop:
for(var i=0; i<input; i++) {
	
	 var numbers = /[0-9]+/;
	inputArray[i] = prompt('Enter Element ' + (i+1));
	if(inputArray[i].match(numbers)){		
			if (Math.sign(inputArray[i])<0){
				alert("Enter positive number");
				inputArray.pop();
				inputArray[i] = prompt('Enter Element ' + (i+1));
				}continue restartloop;
		}else{

			alert("Enter  number only");
			inputArray.pop();
			inputArray[i] = prompt('Enter Element ' + (i+1));
			continue restartloop;
		}
}
console.log(inputArray);


let odd = inputArray.filter(el=>el%2!=0)
console.log(odd);

let cube = inputArray.map((el)=>el**3);
console.log(cube);