var input = prompt('Enter array size');
var inputArray = [];
var size = input; 

for(var i=0; i<size; i++) {
	
	inputArray[i] = prompt('Enter Element ' + (i+1));
}
console.log(inputArray);


let odd = inputArray.filter(el=>el%2!=0)
console.log(odd);

let cube = inputArray.map((el)=>el**3);
console.log(cube);