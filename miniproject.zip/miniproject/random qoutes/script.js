
let quotes=[
'There are three responses to a piece of design – yes, no, and WOW! Wow is the one to aim for.',
'Digital design is like painting, except the paint never dries.',
'The life of a designer is a life of fight. Fight against the ugliness. Just like a doctor fights against disease. For us, the visual disease is what we have around, and what we try to do is cure it somehow with design.',
'A designer knows he has achieved perfection not when there is nothing left to add, but when there is nothing left to take away.',
'Intuitive design is how we give the user new superpowers.',
'The public is more familiar with bad design than good design. It is, in effect, conditioned to prefer bad design, because that is what it lives with. The new becomes threatening, the old reassuring.',
'Technology over technique produces emotionless design.',
'If you think math is hard, try web design',
'Make things as simple as possible, but not simpler.',
'Even large companies need small logos.',
'If you cant explain it simply, you dont understand it well enaugh',
'What separates design from art is that design is meant to be... functional.'
];



function displayQuote(){

    let index=Math.floor(Math.random()*quotes.length);
    let div=document.querySelector('#quote');
    let quote=`<div class="card">
    <p>${quotes[index]}</p>
   </div>
    `;
    div.innerHTML=quote;
    
}

