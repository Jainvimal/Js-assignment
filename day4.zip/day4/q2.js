

const student = {
	name: "Helsinki",
	age:24,
	projects : {
		diceGame: "Two Player dice game using javascript"
	}
}


const[name,age,project:{diceGame}]=student;
console.log(name,age, diceGame);

 

