		
		const Shoppinglist = ['Biscuits', 'Waffer' , 'Hand wash gel', 'soap']
		let item1 = Shoppinglist[0];
		let item2 = Shoppinglist[1];
		let item3 = Shoppinglist[2];
		let item4 = Shoppinglist[3];
		
		console.log(`${item1}`);

		var basket = Shoppinglist;
		basket.push('pulses' ,'Rice');
		console.log(basket);

		var Shoppinglistbasket= [...Shoppinglist , "Butter", "Snacks"];
		console.log(Shoppinglistbasket);
